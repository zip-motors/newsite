"use strict";
$(document).ready(function(){
	$(".rslides").responsiveSlides({
		prevText: "<img src='rasm/prev.png' alt='Previous' style='width:25%;height:auto; bolder: 1 px solid grey;'><span class='bolder'>Oldingi</span>", 
		nextText: "<img src='rasm/next.png' alt='Next' style='width:25%;height:auto;'><span class='bolder'>Keyingi</span>",         
		nav: true,             
		maxwidth: "1920px"           
	});
});
