"use strict";
$(document).ready(function(){
	$("#playvideo").on("click",function(){
		$(".jumbotron.latest.centered").html('<iframe width="100%" height="500px" src="https://mover.uz/video/embed/y1S3o5Dm/" frameborder="0" allowfullscreen></iframe>');
	});
});